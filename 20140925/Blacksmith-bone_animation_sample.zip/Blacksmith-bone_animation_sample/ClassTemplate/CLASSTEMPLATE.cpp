#include "CLASSTEMPLATE.hpp"

using namespace BS;

class CLASSTEMPLATEImpl : public CLASSTEMPLATE {
    
public:
    virtual ~CLASSTEMPLATEImpl() {
    }
    void init();
    // virtual methods
    //void function();
    
private:
    // values
};

std::shared_ptr<CLASSTEMPLATE> CLASSTEMPLATE::Create() {
    std::shared_ptr<CLASSTEMPLATEImpl> ret( new CLASSTEMPLATEImpl() );
    ret->init();
    return ret;
}

void CLASSTEMPLATEImpl::init() {
    
}
