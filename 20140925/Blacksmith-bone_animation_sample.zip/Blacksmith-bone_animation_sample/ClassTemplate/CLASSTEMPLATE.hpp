#ifndef __BLACKSMITH_CLASSTEMPLATE_HPP__
#define __BLACKSMITH_CLASSTEMPLATE_HPP__

#include <memory>

namespace BS {
    
    class CLASSTEMPLATE {
        
    public:
        // > Publish to users. ==================================================================
        static std::shared_ptr<CLASSTEMPLATE> Create();
        //virtual void function() = 0;
        // < Publish to users. ==================================================================
        
    protected:
        virtual ~CLASSTEMPLATE() {}
        explicit CLASSTEMPLATE() {}
        
    private:
        void operator=( const CLASSTEMPLATE& ) {}
        
    };
    
};

#endif
