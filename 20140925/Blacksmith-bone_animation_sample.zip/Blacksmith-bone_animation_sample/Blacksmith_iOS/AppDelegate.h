//
//  AppDelegate.h
//  MetalChallenge001
//
//  Created by takaura-f on 2014/07/16.
//  Copyright (c) 2014 KLab Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
