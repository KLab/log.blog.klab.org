//
//  MetalView.m
//  MetalChallenge001
//
//  Created by takaura-f on 2014/07/16.
//  Copyright (c) 2014 KLab Inc. All rights reserved.
//

#import "MetalView.h"
#import <Metal/Metal.h>
#import "BSRenderer.h"

@implementation MetalView
{
@private
    BSRenderer* renderer;
    id<CAMetalDrawable> currentDrawable;
}

+ (Class) layerClass
{
    return [CAMetalLayer class];
}

- (instancetype) initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    
    if(self)
    {
        self.contentScaleFactor = [UIScreen mainScreen].scale;
        
        { CAMetalLayer *metalLayer = (CAMetalLayer*)(self.layer);
            metalLayer.device = MTLCreateSystemDefaultDevice();
            
            // TODO: review
            /* When false (the default value) changes to the layer's render buffer
             * appear on-screen asynchronously to normal layer updates. When true,
             * changes to the MTL content are sent to the screen via the standard
             * CATransaction mechanisms. */
            metalLayer.presentsWithTransaction = NO;
            
            // TODO: review
            /* When true, the CGContext object passed to the -drawInContext: method
             * may queue the drawing commands submitted to it, such that they will
             * be executed later (i.e. asynchronously to the execution of the
             * -drawInContext: method). This may allow the layer to complete its
             * drawing operations sooner than when executing synchronously. The
             * default value is NO. */
            metalLayer.drawsAsynchronously = YES;
            
            // TODO: review
            /* This property controls the pixel format of the MTLTexture objects.
             * The two supported values are MTLPixelFormatBGRA8Unorm and
             * MTLPixelFormatBGRA8Unorm_sRGB. */
            metalLayer.pixelFormat     = MTLPixelFormatBGRA8Unorm;
            
            // TODO: review
            /* This property controls whether or not the returned drawables'
             * MTLTextures may only be used for framebuffer attachments (YES) or
             * whether they may also be used for texture sampling and pixel
             * read/write operations (NO). A value of YES allows CAMetalLayer to
             * allocate the MTLTexture objects in ways that are optimized for display
             * purposes that makes them unsuitable for sampling. The recommended
             * value for most applications is YES. */
            metalLayer.framebufferOnly = YES;
            
            renderer = [[BSRenderer alloc] initWithDevice:metalLayer.device];
        }
        
    }
    return self;
}

- (void)setContentScaleFactor:(CGFloat)contentScaleFactor
{
    [super setContentScaleFactor:contentScaleFactor];
    
}
- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGSize newSize = self.bounds.size;
    newSize.width *= self.contentScaleFactor;
    newSize.height *= self.contentScaleFactor;
    { CAMetalLayer *metalLayer = (CAMetalLayer*)(self.layer);
        // TODO: review
        /* This property controls the pixel dimensions of the returned drawable
         * objects. The most typical value will be the layer size multiplied by
         * the layer contentsSize property. */
        metalLayer.drawableSize = newSize;
    }
    [renderer reshape:newSize];
}

-(id<CAMetalDrawable>)drawable;
{
    while (currentDrawable == nil)
    {
        currentDrawable = [(CAMetalLayer*)(self.layer) nextDrawable];
        
        if(!currentDrawable)
        {
            NSLog(@"CurrentDrawable is nil");
        }
    }
    return currentDrawable;
}


-(void)display {
    
    // Create autorelease pool per frame to avoid possible deadlock situations
    // because there are 3 CAMetalDrawables sitting in an autorelease pool.
    @autoreleasepool {
        [renderer render:[self drawable] pixelFormat:((CAMetalLayer*)(self.layer)).pixelFormat];
        currentDrawable = nil;
    }
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [renderer touchesBeganFromView:self touches:touches];
}
-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    [renderer touchesMovedFromView:self touches:touches];
}
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    [renderer touchesEndedFromView:self touches:touches];
}

@end
