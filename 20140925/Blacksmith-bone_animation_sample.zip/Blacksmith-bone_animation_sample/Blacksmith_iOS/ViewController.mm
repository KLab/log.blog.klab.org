//
//  ViewController.m
//  MetalChallenge001
//
//  Created by takaura-f on 2014/07/16.
//  Copyright (c) 2014 KLab Inc. All rights reserved.
//

#import "ViewController.h"
#import "MetalView.h"


@implementation ViewController
{
@private
    CADisplayLink *timer;
}
            
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskAll;
}
- (BOOL)shouldAutorotate {
    return YES;
}

-(void)dispatchGameLoop {
    timer = [CADisplayLink displayLinkWithTarget:self
                                        selector:@selector(gameLoop)];
    timer.frameInterval = 1;
    [timer addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
}
-(void)stopGameLoop {
    if(timer) {
        [timer invalidate];
    }
}

-(void)gameLoop {
    
    [(MetalView *)self.view display];
    
}

@end
