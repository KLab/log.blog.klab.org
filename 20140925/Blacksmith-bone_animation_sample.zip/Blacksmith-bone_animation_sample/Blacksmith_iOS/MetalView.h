//
//  MetalView.h
//  MetalChallenge001
//
//  Created by takaura-f on 2014/07/16.
//  Copyright (c) 2014 KLab Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/CAMetalLayer.h>

@interface MetalView : UIView

-(void)display;

@end
