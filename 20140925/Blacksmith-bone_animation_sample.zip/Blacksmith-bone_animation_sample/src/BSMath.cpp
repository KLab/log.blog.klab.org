//
//  BSMath.cpp
//  Blacksmith_iOS
//
//  Created by takaura-f on 2014/08/19.
//  Copyright (c) 2014 KLab Inc. All rights reserved.
//

#include "BSMath.hpp"

static const float f_0_0 = 0.0f;
static const float f_1_0 = 1.0f;
static const float f_2_0 = 2.0f;

static const float deg2rad = float(M_PI) / 180.0f;
float BS::radians(const float& degrees)
{
    return degrees * deg2rad;
}

void BS::Print( const simd::float4x4& f4x4, const std::string& tag ) {
    if( tag.size() ) {
        printf("----- %s -----\n",tag.c_str());
    }
    else {
        printf("--------------\n");
    }
    printf( "| %f %f %f %f |\n", f4x4.columns[0].x, f4x4.columns[0].y, f4x4.columns[0].z, f4x4.columns[0].w);
    printf( "| %f %f %f %f |\n", f4x4.columns[1].x, f4x4.columns[1].y, f4x4.columns[1].z, f4x4.columns[1].w);
    printf( "| %f %f %f %f |\n", f4x4.columns[2].x, f4x4.columns[2].y, f4x4.columns[2].z, f4x4.columns[2].w);
    printf( "| %f %f %f %f |\n", f4x4.columns[3].x, f4x4.columns[3].y, f4x4.columns[3].z, f4x4.columns[3].w);
}
void BS::Print( const simd::float4& f4, const std::string& tag ) {
    printf( "%s( %f, %f, %f, %f )\n", tag.c_str(), f4.x, f4.y, f4.z, f4.w);
}

simd::float4x4 BS::MakeUnitMatrix() {
    static const simd::float4x4 ret {
        simd::float4 {f_1_0,f_0_0,f_0_0,f_0_0},
        simd::float4 {f_0_0,f_1_0,f_0_0,f_0_0},
        simd::float4 {f_0_0,f_0_0,f_1_0,f_0_0},
        simd::float4 {f_0_0,f_0_0,f_0_0,f_1_0}
    };
    return ret;
}

simd::float4x4 BS::perspective(const float& width,
                               const float& height,
                               const float& near,
                               const float& far)
{
    const float zNear = f_2_0 * near;
    const float zFar  = far / (far - near);
    
    return simd::float4x4 {
        simd::float4 { zNear / width, f_0_0, f_0_0, f_0_0 },
        simd::float4 { f_0_0, zNear / height, f_0_0, f_0_0 },
        simd::float4 { f_0_0, f_0_0, zFar, f_1_0 },
        simd::float4 { f_0_0, f_0_0, -near * zFar, f_0_0 }
    };
}

simd::float4x4 BS::perspectiveFov(const float& fovy,
                                  const float& aspect,
                                  const float& near,
                                  const float& far)
{
    const float angle  = radians(0.5f * fovy);
    const float yScale = f_1_0 / std::tan(angle);
    const float xScale = yScale / aspect;
    const float zScale = far / (far - near);
    
    return simd::float4x4 {
        simd::float4 { xScale, f_0_0, f_0_0, f_0_0 },
        simd::float4 { f_0_0, yScale, f_0_0, f_0_0 },
        simd::float4 { f_0_0, f_0_0, zScale, f_1_0 },
        simd::float4 { f_0_0, f_0_0, -near * zScale, f_0_0 }
    };
}

simd::float4x4 BS::lookAt(const simd::float3& eye,
                          const simd::float3& center,
                          const simd::float3& up)
{
    const simd::float3 zAxis = simd::normalize(center - eye);
    const simd::float3 xAxis = simd::normalize(simd::cross(up, zAxis));
    const simd::float3 yAxis = simd::cross(zAxis, xAxis);
    
    return simd::float4x4 {
        simd::float4 { xAxis.x, yAxis.x, zAxis.x, f_0_0 },
        simd::float4 { xAxis.y, yAxis.y, zAxis.y, f_0_0 },
        simd::float4 { xAxis.z, yAxis.z, zAxis.z, f_0_0 },
        simd::float4 { -simd::dot(xAxis, eye), -simd::dot(yAxis, eye), -simd::dot(zAxis, eye), f_1_0 }
    };
}

simd::float4x4 BS::translate(const simd::float4& t)
{
    static const simd::float4x4 UnitMat {
        simd::float4 {f_1_0,f_0_0,f_0_0,f_0_0},
        simd::float4 {f_0_0,f_1_0,f_0_0,f_0_0},
        simd::float4 {f_0_0,f_0_0,f_1_0,f_0_0},
        simd::float4 {f_0_0,f_0_0,f_0_0,f_1_0}
    };
    simd::float4x4 ret = UnitMat;
    ret.columns[3] = simd::float4 {t.x, t.y, t.z, f_1_0};
    return ret;
}

simd::float4x4 BS::scale(const simd::float4& s)
{
    return matrix_from_diagonal( simd::float4 {s.x, s.y, s.z, f_1_0} );
}

simd::float4x4 BS::rotate(const float& angle,
                          const simd::float3& r)
{
    const float a = angle / 180.0f;
    float c = f_0_0;
    float s = f_0_0;
    
    // Computes the sine and cosine of pi times angle (measured in radians)
    // faster and gives exact results for angle = 90, 180, 270, etc.
    __sincospif(a, &s, &c);
    
    const float k = f_1_0 - c;
    
    simd::float3 u = simd::normalize(r);
    simd::float3 v = s * u;
    simd::float3 w = k * u;
    
    return simd::float4x4 {
        simd::float4 { w.x * u.x + c, w.x * u.y + v.z, w.x * u.z - v.y, f_0_0 },
        simd::float4 { w.x * u.y - v.z, w.y * u.y + c, w.y * u.z + v.x, f_0_0 },
        simd::float4 { w.x * u.z + v.y, w.y * u.z - v.x, w.z * u.z + c, f_0_0 },
        simd::float4 { f_0_0, f_0_0, f_0_0, f_1_0 }
    };
}

simd::float4x4 BS::toMatrix(const simd::float4& quaternion) {
    return simd::float4x4 {
        simd::float4 {
            f_1_0-f_2_0*(quaternion.y*quaternion.y + quaternion.z*quaternion.z),
            f_2_0*(quaternion.x*quaternion.y + quaternion.w*quaternion.z),
            f_2_0*(quaternion.x*quaternion.z - quaternion.w*quaternion.y),
            f_0_0
        },
        simd::float4 {
            f_2_0*(quaternion.x*quaternion.y - quaternion.w*quaternion.z),
            f_1_0-f_2_0*(quaternion.x*quaternion.x + quaternion.z*quaternion.z),
            f_2_0*(quaternion.y*quaternion.z + quaternion.w*quaternion.x),
            f_0_0
        },
        simd::float4 {
            f_2_0*(quaternion.x*quaternion.z + quaternion.w*quaternion.y),
            f_2_0*(quaternion.y*quaternion.z - quaternion.w*quaternion.x),
            f_1_0-f_2_0*(quaternion.x*quaternion.x + quaternion.y*quaternion.y),
            f_0_0
        },
        simd::float4 {
            f_0_0,
            f_0_0,
            f_0_0,
            f_1_0
        }
    };
}

simd::float4 BS::slerp( const simd::float4& quaternion_from, const simd::float4& quaternion_to, const float& time_0_quaternion_to_1 ) {
    
    if( time_0_quaternion_to_1 <= f_0_0 ) {
        return quaternion_from;
    }
    else if( f_1_0 <= time_0_quaternion_to_1 ) {
        return quaternion_to;
    }
    
    simd::float4 to;
    float cosom = simd::dot( quaternion_from, quaternion_to );
    if ( cosom < f_0_0 ){
        cosom = - cosom;
        to = - quaternion_to;
    } else  {
        to = quaternion_to;
    }
    
    float scale0, scale1;
    static const float DELTA = 0.00005f;
    if ( (f_1_0 - cosom) > DELTA ) {
        const float omega = acos(cosom);
        const float reciprocal_sinom = f_1_0 / sin(omega);
        scale0 = sin((f_1_0 - time_0_quaternion_to_1) * omega) * reciprocal_sinom;
        scale1 = sin(time_0_quaternion_to_1 * omega) * reciprocal_sinom;
    }
    else {
        scale0 = f_1_0 - time_0_quaternion_to_1;
        scale1 = time_0_quaternion_to_1;
    }
    return scale0 * quaternion_from + scale1 * to;
}
