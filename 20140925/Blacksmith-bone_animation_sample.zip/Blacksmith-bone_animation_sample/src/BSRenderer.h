//
//  BSRenderer.h
//  MetalChallenge001
//
//  Created by takaura-f on 2014/07/16.
//  Copyright (c) 2014 KLab Inc. All rights reserved.
//

#import <Metal/Metal.h>
#import <QuartzCore/CAMetalLayer.h>
#import <UIKit/UIKit.h>

@interface BSRenderer : NSObject
-(instancetype)initWithDevice:(id<MTLDevice>)aDevice;
-(void)reshape:(CGSize)size;
-(void)render:(id<CAMetalDrawable>)drawable pixelFormat:(MTLPixelFormat)pixelFormat;
-(void)touchesBeganFromView:(UIView*)view touches:(NSSet *)touches;
-(void)touchesMovedFromView:(UIView*)view touches:(NSSet *)touches;
-(void)touchesEndedFromView:(UIView*)view touches:(NSSet *)touches;
@end
