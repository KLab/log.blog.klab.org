#ifndef __BLACKSMITH_BSMTLTexture_HPP__
#define __BLACKSMITH_BSMTLTexture_HPP__

#include <memory>
#include <string>

namespace BS {
    
    class BSMTLTexture {
        
    public:
        // > Publish to users. ==================================================================
        static std::shared_ptr<BSMTLTexture> Create2D( const std::string& file_name );
        //static std::shared_ptr<BSMTLTexture> CreateCube( ); // TODO
        // < Publish to users. ==================================================================
        
    protected:
        virtual ~BSMTLTexture() {}
        explicit BSMTLTexture() {}
        
    private:
        void operator=( const BSMTLTexture& ) {}
        
    };
    
};

#endif
