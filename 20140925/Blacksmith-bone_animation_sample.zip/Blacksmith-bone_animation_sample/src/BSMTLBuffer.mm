#include "BSMTLBuffer.hpp"
#import <Metal/Metal.h>
#import "BSMTLHelper.h"

using namespace BS;

class BSMTLBufferImpl : public BSMTLBuffer {
    friend id<MTLBuffer> BSMTLBufferToMTLBuffer( std::shared_ptr<BSMTLBuffer> bsMtlBuffer );
public:
    virtual ~BSMTLBufferImpl() {
        buffer = nil;
    }
    void init( size_t size );
    void init( const void* head_ptr, size_t size );
    void* getContents();
    
private:
    id<MTLBuffer> buffer;
};

std::shared_ptr<BSMTLBuffer> BSMTLBuffer::Create( const void* head_ptr, size_t size ) {
    std::shared_ptr<BSMTLBufferImpl> ret( new BSMTLBufferImpl() );
    ret->init( head_ptr, size );
    return ret;
}

void BSMTLBufferImpl::init( const void* head_ptr, size_t size ) {
    id<MTLDevice> device = GetCurrentDevice();
    if( size > 0 ) {
        buffer = [device newBufferWithBytes:head_ptr length:size options:0];
    }
}

std::shared_ptr<BSMTLBuffer> BSMTLBuffer::Create( size_t size ) {
    std::shared_ptr<BSMTLBufferImpl> ret( new BSMTLBufferImpl() );
    ret->init( size );
    return ret;
}

void BSMTLBufferImpl::init( size_t size ) {
    id<MTLDevice> device = GetCurrentDevice();
    if( size > 0 ) {
        buffer = [device newBufferWithLength:size options:0];
    }
}

void* BSMTLBufferImpl::getContents() {
    return [buffer contents];
}

id<MTLBuffer> BSMTLBufferToMTLBuffer( std::shared_ptr<BSMTLBuffer> bsMtlBuffer ) {
    return dynamic_cast<BSMTLBufferImpl*>(bsMtlBuffer.get())->buffer;
}
