#include "BSMTLTexture.hpp"
#import <Metal/Metal.h>
#import <UIKit/UIKit.h>
#import "BSMTLHelper.h"

using namespace BS;

class BSMTLTextureImpl : public BSMTLTexture {
    friend id<MTLTexture> BSMTLTextureToMTLTexture( std::shared_ptr<BS::BSMTLTexture> bsMtlTexture );
public:
    virtual ~BSMTLTextureImpl() {
        texture = nil;
        width = 0;
        height = 0;
    }
    void init( const std::string& file_name );
    // virtual methods
    //void function();
    
private:
    // values
    id<MTLTexture> texture;
    unsigned int width;
    unsigned int height;
};

std::shared_ptr<BSMTLTexture> BSMTLTexture::Create2D( const std::string& file_name ) {
    std::shared_ptr<BSMTLTextureImpl> ret( new BSMTLTextureImpl() );
    ret->init( file_name );
    return ret;
}

void BSMTLTextureImpl::init( const std::string& file_name ) {
    const unsigned int bytesPerPixel = 4;
    
    NSString *imgPath = [[NSBundle mainBundle] pathForResource:[NSString stringWithUTF8String:file_name.c_str()] ofType:nil];
    UIImage* pImage = [UIImage imageWithContentsOfFile:imgPath];
    if(!pImage) {
        pImage = nil;
        NSLog(@"Error: texture image file not foundd.");
        return;
    }
    
    CGColorSpaceRef pColorSpace = CGColorSpaceCreateDeviceRGB();
    if(!pColorSpace) {
        pImage = nil;
        NSLog(@"Error: texture loading. color space.");
        return;
    }
    
    width = (unsigned int)CGImageGetWidth(pImage.CGImage);
    height = (unsigned int)CGImageGetHeight(pImage.CGImage);
    const unsigned int rowBytes = width * bytesPerPixel;
    
    CGContextRef pContext = CGBitmapContextCreate(NULL,
                                                  width,
                                                  height,
                                                  8,
                                                  rowBytes,
                                                  pColorSpace,
                                                  CGBitmapInfo(kCGImageAlphaPremultipliedLast));
    CGColorSpaceRelease(pColorSpace);
    if(!pColorSpace) {
        NSLog(@"Error: texture loading. context ref.");
        return;
    }
    
    CGRect bounds = CGRectMake(0.0f, 0.0f, width, height);
    
    CGContextClearRect(pContext, bounds);
    
    {  // flip
        CGContextTranslateCTM(pContext, 0, height);
        CGContextScaleCTM(pContext, 1.0, -1.0);
    }
    
    CGContextDrawImage(pContext, bounds, pImage.CGImage);
    
    pImage = nil;
    
    MTLTextureDescriptor *texDesc = [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatRGBA8Unorm
                                                                                        width:width
                                                                                       height:height
                                                                                    mipmapped:NO]; // TODO: mip map
    id<MTLDevice> device = GetCurrentDevice();
    texture = [device newTextureWithDescriptor:texDesc];
    
    texDesc = nil;
    
    if(!texture) {
        CGContextRelease(pContext);
        NSLog(@"Error. texture creation.");
        return;
    }
    
    const void *pPixels = CGBitmapContextGetData(pContext);
    
    if(pPixels != NULL) {
        MTLRegion region = MTLRegionMake2D(0, 0, width, height);
        [texture replaceRegion:region
                   mipmapLevel:0 // TODO: mip map
                     withBytes:pPixels
                   bytesPerRow:rowBytes];
    }
    
    CGContextRelease(pContext);
}


id<MTLTexture> BSMTLTextureToMTLTexture( std::shared_ptr<BS::BSMTLTexture> bsMtlTexture ) {
    return dynamic_cast<BSMTLTextureImpl*>(bsMtlTexture.get())->texture;
}
