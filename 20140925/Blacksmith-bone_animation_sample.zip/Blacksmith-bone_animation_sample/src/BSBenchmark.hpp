//
//  benchmark.hpp
//  MetalChallenge001
//
//  Created by takaura-f on 2014/07/28.
//  Copyright (c) 2014 KLab Inc. All rights reserved.
//

#ifndef __BENCHMARK_HPP__
#define __BENCHMARK_HPP__

#include <chrono>
#include <iostream>
#include <string>

namespace BS {
    
    template <typename F>
    static void benchmark( std::string tag, F func ) {
        
        auto start = std::chrono::system_clock::now(); {
            func();
        } auto end = std::chrono::system_clock::now();
        
        auto diff = end - start;
        std::cout << "[" << tag << "] : " << std::chrono::duration_cast<std::chrono::microseconds>(diff).count() << " microseconds."<< std::endl;
    }
    
};

#endif
