#include "BSModel.hpp"

#include "BSMath.hpp"

// assimp
#include "Importer.hpp"
#include "scene.h"
#include "mesh.h"
#include "postprocess.h"
#include "color4.h"

using namespace BS;


// > Setting ------------------------------------------------------------------------
static const unsigned int PostProcessStepsFlags = (aiProcess_Triangulate
                                                   |aiProcess_GenSmoothNormals
                                                   //|aiProcess_MakeLeftHanded
                                                   //|aiProcess_JoinIdenticalVertices
                                                   );
// < Setting ------------------------------------------------------------------------

// Model -------------------------------------------------------------------------------------------
class BSInternalMaterial {
public:
    static std::shared_ptr<BSInternalMaterial> Create( const aiMaterial* const material ) {
        std::shared_ptr<BSInternalMaterial> ret( new BSInternalMaterial() );
        ret->init( material );
        return ret;
    }
    std::shared_ptr<BSTextureSet> getTextureSet() const { return textureSet; }
private:
    explicit BSInternalMaterial() {}
    
    std::shared_ptr<BSTextureSet> textureSet;
    
    std::vector<std::string> makeTexturePath(  const aiMaterial* const material ,  const aiTextureType& texType ) const {
        std::vector<std::string> ret;
        int texIndex = 0;
        while( true ) {
            aiString retTexPath;
            if( material->GetTexture(texType, texIndex, &retTexPath) != AI_SUCCESS ) { break; }
            ret.push_back( std::string(retTexPath.data) );
            ++texIndex;
        }
        return ret;
    }
    
    void init( const aiMaterial* const material ) {
        textureSet = std::shared_ptr<BSTextureSet>(new BSTextureSet());
        // texture ----------------------------------
        {
            // diffuse texture
            {
                std::vector<std::string> texPaths = makeTexturePath( material, aiTextureType_DIFFUSE );
                for( std::string texPath : texPaths ) {
                    textureSet->diffuse.push_back( BSMTLTexture::Create2D( texPath ) );
                }
            }
            // normal texture
            {
                std::vector<std::string> texPaths = makeTexturePath( material, aiTextureType_NORMALS );
                for( std::string texPath : texPaths ) {
                    textureSet->normal.push_back( BSMTLTexture::Create2D( texPath ) );
                }
            }
            // TODO: add another type texture...
        }
    }
};

class BSInternalMesh {
public:
    static std::shared_ptr<BSInternalMesh> Create( const aiMesh* const mesh, const bool& bone_animation_included ) {
        std::shared_ptr<BSInternalMesh> ret( new BSInternalMesh() );
        ret->init( mesh, bone_animation_included );
        return ret;
    }
    std::string getName() const { return name; }
    unsigned int getMaterialIndex() const { return materialIndex; }
    std::shared_ptr<BSMTLBuffer> getVertexes() const { return vertexes; }
    unsigned int getVertexCount() const { return vertexCount; }
    std::shared_ptr<BSMTLBuffer> getVertexIndices() const { return vertexIndices; }
    unsigned int getVertexIndexCount() { return vertexIndexCount; }
private:
    explicit BSInternalMesh() {}
    
    // values
    std::string name;
    std::shared_ptr<BSMTLBuffer> vertexes;
    unsigned int vertexCount;
    std::shared_ptr<BSMTLBuffer> vertexIndices;
    unsigned int vertexIndexCount;
    unsigned int materialIndex;
    
    void init( const aiMesh* const mesh, const bool& bone_animation_included ) {
        
        materialIndex = mesh->mMaterialIndex;
        
        name = std::string( mesh->mName.data );
        
        {  // vertexes
            const float const_float_1_0 = 1.0f;
            if( !bone_animation_included ) {  // without boneIdx & weight
                BSVertex* vs = (BSVertex*)malloc( mesh->mNumVertices * sizeof(BSVertex) ); {
                    for( unsigned int i=0; i<mesh->mNumVertices; ++i ) {
                        vs[i].position = { mesh->mVertices[i].x, mesh->mVertices[i].y, mesh->mVertices[i].z, const_float_1_0 };
                        vs[i].normal = { mesh->mNormals[i].x, mesh->mNormals[i].y, mesh->mNormals[i].z, const_float_1_0 };
                        if( mesh->HasTextureCoords(0) ) { vs[i].uv = { mesh->mTextureCoords[0][i].x, mesh->mTextureCoords[0][i].y, mesh->mTextureCoords[0][i].z }; }
                        else {
                            vs[i].uv = { 0.0f, 0.0f, 0.0f };
                        }
                        if( mesh->HasVertexColors(0) ) { vs[i].color = { mesh->mColors[0][i].r, mesh->mColors[0][i].g, mesh->mColors[0][i].b, mesh->mColors[0][i].a }; }
                        else { vs[i].color = { 1.0f, 1.0f, 1.0f, 1.0f }; };
                    }
                    vertexes = BSMTLBuffer::Create( vs, mesh->mNumVertices * sizeof(BSVertex) );
                } free(vs); vs = nullptr;
            }
            else {  // with boneIdx & weight
                BSBoneAnimVertex* vs = (BSBoneAnimVertex*)malloc( mesh->mNumVertices * sizeof(BSBoneAnimVertex) ); {
                    for( unsigned int i=0; i<mesh->mNumVertices; ++i ) {
                        vs[i].position = { mesh->mVertices[i].x, mesh->mVertices[i].y, mesh->mVertices[i].z, const_float_1_0 };
                        vs[i].normal = { mesh->mNormals[i].x, mesh->mNormals[i].y, mesh->mNormals[i].z, const_float_1_0 };
                        if( mesh->HasTextureCoords(0) ) { vs[i].uv = { mesh->mTextureCoords[0][i].x, mesh->mTextureCoords[0][i].y, mesh->mTextureCoords[0][i].z }; }
                        else {
                            vs[i].uv = { 0.0f, 0.0f, 0.0f };
                        }
                        if( mesh->HasVertexColors(0) ) { vs[i].color = { mesh->mColors[0][i].r, mesh->mColors[0][i].g, mesh->mColors[0][i].b, mesh->mColors[0][i].a }; }
                        else { vs[i].color = { 1.0f, 1.0f, 1.0f, 1.0f }; };
                        vs[i].boneIdx = simd::ushort4 {0,0,0,0};
                        vs[i].weights = simd::float4 {0.0f,0.0f,0.0f,0.0f};
                    }
                    vertexes = BSMTLBuffer::Create( vs, mesh->mNumVertices * sizeof(BSBoneAnimVertex) );
                } free(vs); vs = nullptr;
            }
            vertexCount = mesh->mNumVertices;
        }
        
        {  // vertex indices
            unsigned int *vids = (unsigned int*)malloc(  mesh->mNumFaces * 3 * sizeof(unsigned int) ); /* This implimentation assumes that each face has only 3 indices because by aiProcess_Triangulate */ {
                for( unsigned int f=0; f<mesh->mNumFaces; ++f ) {
                    for( unsigned int i_0_to_2=0; i_0_to_2<mesh->mFaces[f].mNumIndices/* ==3 because by aiProcess_Triangulate */; ++i_0_to_2 ) {
                        vids[f*3+i_0_to_2] = mesh->mFaces[f].mIndices[i_0_to_2];
                    }
                }
                vertexIndices = BSMTLBuffer::Create( vids, mesh->mNumFaces * 3 * sizeof(unsigned int) );
            } free(vids); vids = nullptr;
            vertexIndexCount = mesh->mNumFaces * 3;
        }
        
    }
};

class BSModelImpl : public BSModel {
public:
    virtual ~BSModelImpl() {}
    explicit BSModelImpl() {}
    void initMaterial( const aiScene* const scene );  // non virtual
    virtual void initMesh( const aiScene* const scene );  // virtual
    
    // virtual methods
    virtual std::map<std::string,BSRenderingData> getRenderingData() const;
    
protected:
    std::vector<std::shared_ptr<BSInternalMaterial>> materials;
    std::vector<std::shared_ptr<BSInternalMesh>> meshes;
};

std::shared_ptr<BSModel> BSModel::Create( const std::string& file_path ) {
    std::shared_ptr<BSModelImpl> ret( new BSModelImpl() );
    Assimp::Importer importer;
    importer.ReadFile( file_path, PostProcessStepsFlags );
    ret->initMaterial( importer.GetScene() );
    ret->initMesh( importer.GetScene() );
    return ret;
}
void BSModelImpl::initMaterial( const aiScene* const scene ) {
    materials.reserve( scene->mNumMaterials );
    for( unsigned int i=0; i<scene->mNumMaterials; ++i ) {
        materials.push_back( BSInternalMaterial::Create( scene->mMaterials[i] ) );
    }
}
void BSModelImpl::initMesh( const aiScene* const scene ) {
    meshes.reserve( scene->mNumMeshes );
    for( unsigned int i=0; i<scene->mNumMeshes; ++i ) {
        meshes.push_back( BSInternalMesh::Create( scene->mMeshes[i], false ) );
    }
}

static BSRenderingDataWithAnimation MakeRenderingData( std::shared_ptr<BSInternalMesh> mesh, std::vector<std::shared_ptr<BSInternalMaterial>> materials ) {
    BSRenderingDataWithAnimation ret;
    ret.vertexBuffer = mesh->getVertexes();
    ret.vertexCount = mesh->getVertexCount();
    ret.vertexIndexBuffer = mesh->getVertexIndices();
    ret.vertexIndexCount = mesh->getVertexIndexCount();;
    ret.textureSet = materials[mesh->getMaterialIndex()]->getTextureSet();
    return ret;
}

std::map<std::string,BSRenderingData> BSModelImpl::getRenderingData() const {
    std::map<std::string,BSRenderingData> ret;
    for( unsigned int i=0; i<meshes.size(); ++i ) {
        ret[meshes[i]->getName()] = MakeRenderingData( meshes[i], materials );
    }
    return ret;
}


// Animation Model -------------------------------------------------------------------------------------------
namespace AssimpMathHelper {
    
    static simd::float4x4 Make_simd_float4x4( const aiMatrix4x4& mat ) {
        return simd::float4x4 {
            simd::float4{ mat.a1, mat.b1, mat.c1, mat.d1 },
            simd::float4{ mat.a2, mat.b2, mat.c2, mat.d2 },
            simd::float4{ mat.a3, mat.b3, mat.c3, mat.d3 },
            simd::float4{ mat.a4, mat.b4, mat.c4, mat.d4 }
        };
    }
    
    static simd::float4 Make_simd_float4( const aiVector3D& vec ) {
        return simd::float4 { vec.x, vec.y, vec.z, 1.0f };
    }
    
    static simd::float4 Make_simd_float4( const aiQuaternion& qua ) {
        return simd::float4 { qua.x, qua.y, qua.z, qua.w };
    }
    
};

static const float FLOAT_SMALL_NUM = 0.00005f;
static simd::float4 InterpolateVector( const std::vector<std::pair<float,simd::float4>>& v,
                                       const float& time,
                                       const simd::float4& initialVal ) {
    if( v.size() == 0 ) { return initialVal; }
    else if( v.size() == 1 ) { return v[0].second; }
    
    const float posiTargetTime = (time>=0.0f) ? time : 0.0f;
    
    float lowTime = posiTargetTime;
    float highTime = posiTargetTime;
    simd::float4 lowFactor { v[0].second };
    simd::float4 highFactor { v[v.size()-1].second };
    
    for( unsigned int i=0; i<v.size(); ++i ) {
        const float currentTime = v[i].first;
        if( currentTime > posiTargetTime ) { break; }
        else {
            lowTime = currentTime;
            lowFactor = v[i].second;
        }
    }
    for( int i=(int)v.size()-1; i>=0; --i ) {
        const float currentTime = v[i].first;
        if( currentTime < posiTargetTime ) { break; }
        else {
            highTime = currentTime;
            highFactor = v[i].second;
        }
    }
    
    if( (lowTime + highTime) < FLOAT_SMALL_NUM ) {
        return lowFactor;
    }
    const float time_0_1 = (posiTargetTime - lowTime)/(lowTime+highTime);
    return (lowFactor * time_0_1) + (highFactor * (1.0-time_0_1));
}
static simd::float4 InterpolateQuaternion( const std::vector<std::pair<float,simd::float4>>& v,
                                           const float& time ) {
    static const simd::float4 noRotateVal {0.0f,1.0f,0.0f,0.0f};
    if( v.size() == 0 ) { return noRotateVal; }
    else if( v.size() == 1 ) { return v[0].second; }
    
    const float posiTargetTime = (time>=0.0f) ? time : 0.0f;
    
    float lowTime = posiTargetTime;
    float highTime = posiTargetTime;
    simd::float4 lowFactor { v[0].second };
    simd::float4 highFactor { v[v.size()-1].second };
    
    for( unsigned int i=0; i<v.size(); ++i ) {
        const float currentTime = v[i].first;
        if( currentTime > posiTargetTime ) { break; }
        else {
            lowTime = currentTime;
            lowFactor = v[i].second;
        }
    }
    for( int i=(int)v.size()-1; i>=0; --i ) {
        const float currentTime = v[i].first;
        if( currentTime < posiTargetTime ) { break; }
        else {
            highTime = currentTime;
            highFactor = v[i].second;
        }
    }
    
    if( (lowTime + highTime) < FLOAT_SMALL_NUM ) {
        return lowFactor;
    }
    return slerp( lowFactor, highFactor, (posiTargetTime - lowTime)/(lowTime+highTime) );
}

class BSInternalNodeAnimation {
    
public:
    static std::shared_ptr<BSInternalNodeAnimation> Create( const aiNodeAnim* const nodeAnim ) {
        std::shared_ptr<BSInternalNodeAnimation> ret( new BSInternalNodeAnimation() );
        ret->init( nodeAnim );
        return ret;
    }
    simd::float4x4 getNodeMatrixAtTime( const float& time_0_to_1 ) const {
        const float time = rotationAtTime.front().first + (rotationAtTime.back().first - rotationAtTime.front().first) * time_0_to_1;  // TODO:
        static const simd::float4 scaleInitVal {1.0f,1.0f,1.0f,1.0f};
        simd::float4 scaleKey = InterpolateVector( scaleAtTime, time, scaleInitVal );
        static const simd::float4 traInitVal {0.0f,0.0f,0.0f,1.0f};
        simd::float4 translationKey = InterpolateVector( translationAtTime, time, traInitVal );
        simd::float4 rotationKey = InterpolateQuaternion( rotationAtTime, time );
        return translate( translationKey ) * toMatrix( rotationKey ) * scale( scaleKey );
    }
    
private:
    explicit BSInternalNodeAnimation() {}
    
    void init( const aiNodeAnim* const nodeAnim ) {
        scaleAtTime.reserve( nodeAnim->mNumScalingKeys );
        rotationAtTime.reserve( nodeAnim->mNumRotationKeys );
        translationAtTime.reserve( nodeAnim->mNumPositionKeys );
        for( unsigned int s=0; s<nodeAnim->mNumScalingKeys; ++s ) {
            const aiVectorKey& key = nodeAnim->mScalingKeys[s];
            scaleAtTime.push_back( std::make_pair(key.mTime, AssimpMathHelper::Make_simd_float4( key.mValue )) );
        }
        for( unsigned int r=0; r<nodeAnim->mNumRotationKeys; ++r ) {
            const aiQuatKey& key = nodeAnim->mRotationKeys[r];
            rotationAtTime.push_back( std::make_pair(key.mTime, AssimpMathHelper::Make_simd_float4( key.mValue )) );
        }
        for( unsigned int p=0; p<nodeAnim->mNumPositionKeys; ++p ) {
            const aiVectorKey& key = nodeAnim->mPositionKeys[p];
            translationAtTime.push_back( std::make_pair(key.mTime, AssimpMathHelper::Make_simd_float4( key.mValue )) );
        }
    }
    
    std::vector<std::pair<float,simd::float4>> scaleAtTime;
    std::vector<std::pair<float,simd::float4/* quaternion */>> rotationAtTime;
    std::vector<std::pair<float,simd::float4>> translationAtTime;
    
};

class BSInternalAnimation {
    
public:
    static std::shared_ptr<BSInternalAnimation> Create( const aiAnimation* const anim ) {
        std::shared_ptr<BSInternalAnimation> ret( new BSInternalAnimation() );
        ret->init( anim );
        return ret;
    }
    inline const std::map<std::string,std::shared_ptr<BSInternalNodeAnimation>>& getNodeAnims() const { return nodeAnims; }// key: nodeName
    
private:
    explicit BSInternalAnimation() {}
    
    void init( const aiAnimation* const anim ) {
        for( unsigned int i=0; i<anim->mNumChannels; ++i ) {
            name = std::string( anim->mName.data );
            const aiNodeAnim* const currentNodeAnim = anim->mChannels[i];
            nodeAnims[std::string(currentNodeAnim->mNodeName.data)] = BSInternalNodeAnimation::Create( currentNodeAnim );
        }
        for( unsigned int i=0; i<anim->mNumMeshChannels; ++i ) {
            // TODO: mesh animation
        }
    }
    
    std::string name;
    std::map<std::string,std::shared_ptr<BSInternalNodeAnimation>> nodeAnims;  // key: nodeName
};

class BSInternalNode : public std::enable_shared_from_this<BSInternalNode> {

public:
    static std::shared_ptr<BSInternalNode> Create( const aiNode* const node ) {
        std::shared_ptr<BSInternalNode> ret( new BSInternalNode() );
        ret->initSelf( node );
        ret->createChildren( node );
        return ret;
    }
    std::string getName() const { return name; }
    inline const simd::float4x4& getCalculatedTransformationMatrixFromOrigin() const { return calculatedTransformationFromOrigin; }
    void recAnim( const std::map<std::string,std::shared_ptr<BSInternalNodeAnimation>>& nodeAnims, const float& time_0_to_1 ) {
        /* nodeAnims - key: node name, val: node animation */
        {  // > current node process --------------------------------------------
            std::shared_ptr<BSInternalNodeAnimation> nodeAnim = nullptr;
            if( nodeAnims.count(name) ) { nodeAnim = nodeAnims.at(name); }
            std::shared_ptr<BSInternalNode> parentPtr = parent.lock();
            if( parentPtr && nodeAnim ) /* animation child node */ {
                calculatedTransformationFromOrigin = parentPtr->calculatedTransformationFromOrigin * nodeAnim->getNodeMatrixAtTime(time_0_to_1);
            }
            else if( parentPtr && !nodeAnim ) /* no anim child node */ {
                calculatedTransformationFromOrigin = parentPtr->calculatedTransformationFromOrigin * transformationFromParent;
            }
            else if( !parentPtr && nodeAnim ) /* animation root node */ {
                calculatedTransformationFromOrigin = transformationFromParent * nodeAnim->getNodeMatrixAtTime(time_0_to_1);
            }
            else /* if( !parentPtr && !nodeAnim ) */ /* no anim root node */ {
                calculatedTransformationFromOrigin = transformationFromParent;
            }
        }  // < current node process --------------------------------------------
        for( unsigned int i=0; i<children.size(); ++i ) {
            children[i]->recAnim( nodeAnims, time_0_to_1 );
        }
    }
    std::shared_ptr<BSInternalNode> findNode( const std::string target_name ) {
        // TODO: tune this method using std::map cache.
        if( target_name == name ) {
            return shared_from_this();
        }
        std::shared_ptr<BSInternalNode> ret;
        for( unsigned int i=0; i<children.size(); ++i ) {
            std::shared_ptr<BSInternalNode> child = children[i];
            ret = child->findNode( target_name );
            if( ret ) {
                return ret;
            }
        }
        return ret;
    }
    
private:
    explicit BSInternalNode() : transformationFromParent( MakeUnitMatrix() ), calculatedTransformationFromOrigin( MakeUnitMatrix() ) {}
    void initSelf( const aiNode* const node ) {
        name = std::string( node->mName.data );
        transformationFromParent = AssimpMathHelper::Make_simd_float4x4( node->mTransformation );
    }
    void createChildren( const aiNode* const node ) {
        // children
        children.reserve( node->mNumChildren );
        for( unsigned int i=0; i<node->mNumChildren; ++i ) {
            const aiNode* const currentChild = node->mChildren[i];
            std::shared_ptr<BSInternalNode> chd = BSInternalNode::Create( currentChild );
            chd->parent = shared_from_this();
            children.push_back( chd );
        }
    }
    
    // values
    std::string name;
    simd::float4x4 transformationFromParent;  // original data
    simd::float4x4 calculatedTransformationFromOrigin;  // calculated(per frame) data
    std::weak_ptr<BSInternalNode> parent;
    std::vector<std::shared_ptr<BSInternalNode>> children;
};

static void SwapFloat( float* f1, float* f2 ) {
    float temp = *f1;
    *f1 = *f2;
    *f2 = temp;
}
/* ret: index,
 *              not added:-1,
 *              added to x:0,
 *              added to y:1,
 *              added to z:2,
 *              added to w:3
 */
static int InsertWeight( const float& w, simd::float4* weight ) {
    int ret = -1;
    if( weight->w < w ) {
        weight->w = w;
        ret = 3;
    }
    else {
        return ret;  // -1
    }
    
    if( weight->z < weight->w ) {
        float a = weight->z;
        float b = weight->w;
        SwapFloat( &a, &b );
        weight->z = a;
        weight->w = b;
        ret = 2;
    }
    if( weight->y < weight->z ) {
        float a = weight->y;
        float b = weight->z;
        SwapFloat( &a, &b );
        weight->y = a;
        weight->z = b;
        ret = 1;
    }
    if( weight->x < weight->y ) {
        float a = weight->x;
        float b = weight->y;
        SwapFloat( &a, &b );
        weight->x = a;
        weight->y = b;
        ret = 0;
    }
    return ret;
}

class BSInternalBone {

public:
    static std::shared_ptr<BSInternalBone> Create( const aiBone* const bone, const unsigned int& boneIdx, std::shared_ptr<BSMTLBuffer/* BSBoneAnimVertex */> vertexBufferWithBoneAnim ) {
        std::shared_ptr<BSInternalBone> ret( new BSInternalBone() );
        ret->init( bone, boneIdx, vertexBufferWithBoneAnim );
        return ret;
    }
    
    std::string getName() const { return name; }
    simd::float4x4 getOffsetMatrix() const { return offsetMatrix; }

private:
    explicit BSInternalBone() {}
    void init( const aiBone* const bone, const unsigned int& boneIdx, std::shared_ptr<BSMTLBuffer/* BSBoneAnimVertex */> vertexBufferWithBoneAnim ) {
        name = std::string( bone->mName.data );
        offsetMatrix = AssimpMathHelper::Make_simd_float4x4( bone->mOffsetMatrix );
        {  // add weight param to vertices
            for( unsigned int w=0; w<bone->mNumWeights; ++w ) {
                const unsigned int vId = bone->mWeights[w].mVertexId;
                const float weight = bone->mWeights[w].mWeight;
                BSBoneAnimVertex& currentVertex = ((BSBoneAnimVertex*)vertexBufferWithBoneAnim->getContents())[vId];
                const int insertedIdx = InsertWeight(weight, &currentVertex.weights);
                if( insertedIdx == -1 ) { /* nop. */ }
                else if( insertedIdx == 0 ) {
                    currentVertex.boneIdx.w = currentVertex.boneIdx.z;
                    currentVertex.boneIdx.z = currentVertex.boneIdx.y;
                    currentVertex.boneIdx.y = currentVertex.boneIdx.x;
                    currentVertex.boneIdx.x = boneIdx;
                }
                else if( insertedIdx == 1 ) {
                    currentVertex.boneIdx.z = currentVertex.boneIdx.y;
                    currentVertex.boneIdx.y = currentVertex.boneIdx.x;
                    currentVertex.boneIdx.y = boneIdx;
                }
                else if( insertedIdx == 2 ) {
                    currentVertex.boneIdx.y = currentVertex.boneIdx.x;
                    currentVertex.boneIdx.z = boneIdx;
                }
                else if( insertedIdx == 3 ) {
                    currentVertex.boneIdx.w = boneIdx;
                }
            }
        }
    }
    
    std::string name;
    simd::float4x4 offsetMatrix;
    
};

class Counter {
public:
    explicit Counter( const unsigned int& limit_value ) : limit(limit_value) { count = 0; }
    void increment() { count = ++count % limit; }
    unsigned int getCount() const { return count; }
    unsigned int getLimit() const { return limit; }
private:
    unsigned int count;
    const unsigned int limit;
};

class BSAnimModelImpl : public BSAnimModel/*Interface*/, public BSModelImpl {
    
public:
    virtual ~BSAnimModelImpl() {}
    explicit BSAnimModelImpl( const unsigned int& num_of_command_buffers_in_command_queue ) : frameIdx(num_of_command_buffers_in_command_queue) {}
    void initMesh( const aiScene* const scene );  // virtual from BSModelImpl
    void initAnimRelatedParams( const aiScene* const scene );
    
    // virtual methods
    std::map<std::string,BSRenderingData> getRenderingData() const;
    std::map<std::string,BSRenderingDataWithAnimation> getRenderingDataWithAnimation() const;
    void calcBone( const std::string& animation_name, const float& time_0_to_1 );
    
private:
    Counter frameIdx;
    std::shared_ptr<BSInternalNode> rootNode;
    /* key: animation name, val: animation */
    std::map<std::string,std::shared_ptr<BSInternalAnimation>> animations;
    /* key: mesh name, val: bones */
    std::map<std::string,std::vector<std::shared_ptr<BSInternalBone>>> skeleton;
    /* key: mesh name, val: buffers(...[bone matrix]...), num of buffers: frameIdx.getLimit() */
    std::map<std::string,std::vector<std::shared_ptr<BSMTLBuffer>>> boneMatrixBuffers;
};

std::shared_ptr<BSAnimModel> BSAnimModel::Create( const std::string& file_path,  const unsigned int& num_of_command_buffers_in_command_queue  ) {
    std::shared_ptr<BSAnimModelImpl> ret( new BSAnimModelImpl(num_of_command_buffers_in_command_queue) );
    Assimp::Importer importer;
    importer.ReadFile( file_path, PostProcessStepsFlags );
    ret->initMaterial( importer.GetScene() );
    ret->initMesh( importer.GetScene() );
    ret->initAnimRelatedParams( importer.GetScene() );
    return ret;
}
void BSAnimModelImpl::initMesh( const aiScene* const scene ) {
    meshes.reserve( scene->mNumMeshes );
    for( unsigned int i=0; i<scene->mNumMeshes; ++i ) {
        meshes.push_back( BSInternalMesh::Create( scene->mMeshes[i], true ) );
    }
}
void BSAnimModelImpl::initAnimRelatedParams( const aiScene* const scene ) {
    
    {  // make nodes
        rootNode = BSInternalNode::Create( scene->mRootNode );
    }
    
    {  // make skeleton, boneMatrixBuffers
        for( unsigned int m=0; m<meshes.size(); ++m ) {
            const aiMesh* const currentAiMesh = scene->mMeshes[m];
            const std::string currentMeshName = meshes[m]->getName();
            
            for( unsigned int b=0; b<currentAiMesh->mNumBones; ++b ) {  // skeleton
                skeleton[currentMeshName].push_back( BSInternalBone::Create( currentAiMesh->mBones[b], b, meshes[m]->getVertexes() ) );
            }
            
            for( unsigned int c=0; c<frameIdx.getLimit(); ++c ) {  // boneMatrixBuffers
                boneMatrixBuffers[currentMeshName].push_back( BSMTLBuffer::Create( sizeof(simd::float4x4)*currentAiMesh->mNumBones ) );
            }
        }
    }
    
    {  // make animations
        for( unsigned int i=0; i<scene->mNumAnimations; ++i ) {
            const aiAnimation* const currentAnim = scene->mAnimations[i];
            animations.insert( std::make_pair(std::string(currentAnim->mName.data), BSInternalAnimation::Create(scene->mAnimations[i])) );
        }
    }
    
}

void BSAnimModelImpl::calcBone( const std::string& animation_name, const float& time_0_to_1 ) {
    
    // step1. calc node : nodeAnimedMatrix
    {
        std::shared_ptr<BSInternalAnimation> anim = animations[animation_name];
        if( anim ) {
            rootNode->recAnim( anim->getNodeAnims(), time_0_to_1 );
        }
        else {
            
        }
    }
    
    // step2. calc bone matrix : boneMatrix = nodeAnimedMatrix * boneOffsetMatrix
    {
        for( unsigned int m=0; m<meshes.size(); ++m ) {
            const std::string currentMeshName = meshes[m]->getName();
            const std::vector<std::shared_ptr<BSInternalBone>>& currentBonesInMesh = skeleton[currentMeshName];
            for( unsigned int b=0; b<currentBonesInMesh.size(); ++b ) {
                std::shared_ptr<BSInternalBone> currentBone = currentBonesInMesh[b];
                std::shared_ptr<BSInternalNode> foundNode = rootNode->findNode( currentBone->getName() );
                if( foundNode ) {
                    ((simd::float4x4*)boneMatrixBuffers[currentMeshName][frameIdx.getCount()]->getContents())[b] = foundNode->getCalculatedTransformationMatrixFromOrigin() * currentBone->getOffsetMatrix();
                }
                else {
                    ((simd::float4x4*)boneMatrixBuffers[currentMeshName][frameIdx.getCount()]->getContents())[b] = currentBone->getOffsetMatrix();
                }
            }
        }
    }
    
    // step3. calc InverseKinematics or ForwardKinematics
    {
        // nop.
    }
    
    // step4. update frameIdx
    {
        frameIdx.increment();
    }
    
}

std::map<std::string,BSRenderingData> BSAnimModelImpl::getRenderingData() const {
    return BSModelImpl::getRenderingData();
}
std::map<std::string,BSRenderingDataWithAnimation> BSAnimModelImpl::getRenderingDataWithAnimation() const {
    std::map<std::string,BSRenderingDataWithAnimation> ret;
    for( unsigned int i=0; i<meshes.size(); ++i ) {
        const std::string meshName = meshes[i]->getName();
        ret[meshName] = MakeRenderingData( meshes[i], materials );
        ret[meshName].boneMatrixBuffer = boneMatrixBuffers.at(meshName)[frameIdx.getCount()];
    }
    return ret;
}
