//
//  BSMTLHelper.h
//  Blacksmith_iOS
//
//  Created by takaura-f on 2014/08/07.
//  Copyright (c) 2014 KLab Inc. All rights reserved.
//

#ifndef Blacksmith_iOS_BSMTLHelper_h
#define Blacksmith_iOS_BSMTLHelper_h

/*
 *  This header file can't be imcluded from cpp file. (Only mm file can include me.)
 */

#include <memory>

id<MTLDevice> GetCurrentDevice();
void SetCurrentDevice( id<MTLDevice> device );

#include "BSMTLBuffer.hpp"
id<MTLBuffer> BSMTLBufferToMTLBuffer( std::shared_ptr<BS::BSMTLBuffer> bsMtlBuffer );

#include "BSMTLTexture.hpp"
id<MTLTexture> BSMTLTextureToMTLTexture( std::shared_ptr<BS::BSMTLTexture> bsMtlTexture );


#endif
