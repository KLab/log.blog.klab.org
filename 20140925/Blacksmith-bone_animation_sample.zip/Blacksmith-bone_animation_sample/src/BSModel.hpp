#ifndef __BLACKSMITH_BSModel_HPP__
#define __BLACKSMITH_BSModel_HPP__

#include <memory>
#include <string>
#include <vector>
#include <map>

#include "BSVertex.hpp"

// Apple dependence
#include <simd/simd.h>
#include "BSMTLBuffer.hpp"
#include "BSMTLTexture.hpp"

namespace BS {
    
    struct BSTextureSet {
        std::vector<std::shared_ptr<BSMTLTexture>> diffuse;
        std::vector<std::shared_ptr<BSMTLTexture>> normal;
        // TODO: etc...
    };
    
    struct BSRenderingData {
        std::shared_ptr<BSMTLBuffer/* BSVertex */> vertexBuffer;
        unsigned int vertexCount;
        std::shared_ptr<BSMTLBuffer/* unsigned int */> vertexIndexBuffer;
        unsigned int vertexIndexCount;
        std::shared_ptr<BSTextureSet> textureSet;
        // TODO: etc...
    };
    
    class BSModel {
        
    public:
        // > Publish to users. ==================================================================
        static std::shared_ptr<BSModel> Create( const std::string& file_path );
        virtual std::map<std::string,BSRenderingData> getRenderingData() const = 0;  // key: mesh name
        // < Publish to users. ==================================================================
        
    protected:
        virtual ~BSModel() {}
        explicit BSModel() {}
        
    private:
        void operator=( const BSModel& ) {}
        
    };
    
    struct BSRenderingDataWithAnimation : public BSRenderingData {
        std::shared_ptr<BSMTLBuffer/* simd::float4x4 */> boneMatrixBuffer;
    };
    
    class BSAnimModel {
        
    public:
        // > Publish to users. ==================================================================
        static std::shared_ptr<BSAnimModel> Create( const std::string& file_path, const unsigned int& num_of_command_buffers_in_command_queue );
        virtual std::map<std::string,BSRenderingData> getRenderingData() const = 0;  // Original(non-animated) mesh data.
        virtual std::map<std::string,BSRenderingDataWithAnimation> getRenderingDataWithAnimation() const = 0;
        virtual void calcBone( const std::string& animation_name, const float& time_0_to_1 ) = 0;
        // < Publish to users. ==================================================================
        
    protected:
        virtual ~BSAnimModel() {}
        explicit BSAnimModel() {}
        
    private:
        void operator=( const BSAnimModel& ) {}
        
    };
    
};

#endif
