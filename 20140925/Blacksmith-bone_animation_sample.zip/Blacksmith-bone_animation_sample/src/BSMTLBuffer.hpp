#ifndef __BLACKSMITH_BSMTLBuffer_HPP__
#define __BLACKSMITH_BSMTLBuffer_HPP__

#include <memory>

namespace BS {
    
    class BSMTLBuffer {
        
    public:
        // > Publish to users. ==================================================================
        static std::shared_ptr<BSMTLBuffer> Create( size_t size );
        static std::shared_ptr<BSMTLBuffer> Create( const void* head_ptr, size_t size );
        virtual void* getContents() = 0;  // do not free returned pointer.
        // < Publish to users. ==================================================================
        
    protected:
        virtual ~BSMTLBuffer() {}
        explicit BSMTLBuffer() {}
        
    private:
        void operator=( const BSMTLBuffer& ) {}
        
    };
    
};

#endif
