//
//  BSMath.hpp
//  Blacksmith_iOS
//
//  Created by takaura-f on 2014/08/19.
//  Copyright (c) 2014 KLab Inc. All rights reserved.
//

#ifndef __BSMATH_HPP__
#define __BSMATH_HPP__

// Apple dependence
#include <simd/simd.h>

// stl
#include <string>

namespace BS {
    
    void Print( const simd::float4x4& f4x4, const std::string& tag = "" );
    void Print( const simd::float4& f4, const std::string& tag = "" );
    
    simd::float4x4 MakeUnitMatrix();
    
    float radians(const float& degrees);
    
    simd::float4x4 perspective(const float& width,
                               const float& height,
                               const float& near,
                               const float& far);
    
    simd::float4x4 perspectiveFov(const float& fovy,
                                  const float& aspect,
                                  const float& near,
                                  const float& far);
    
    simd::float4x4 lookAt(const simd::float3& eye,
                          const simd::float3& center,
                          const simd::float3& up);
    
    simd::float4x4 translate(const simd::float4& t);
    
    simd::float4x4 scale(const simd::float4& s);
    
    simd::float4x4 rotate(const float& angle,
                          const simd::float3& r);
    
    simd::float4x4 toMatrix(const simd::float4& quaternion);
    
    simd::float4 slerp( const simd::float4& quaternion_from, const simd::float4& quaternion_to, const float& time_0_to_1 );
    
};

#endif
