//
//  BSVertex.hpp
//  Blacksmith_iOS
//
//  Created by takaura-f on 2014/09/02.
//  Copyright (c) 2014 KLab Inc. All rights reserved.
//

#ifndef __BLACKSMITH_BSVertex_HPP__
#define __BLACKSMITH_BSVertex_HPP__

#include <simd/simd.h>


namespace BS {
    
    struct BSVertex {  // TODO: other format
        simd::float4 position;
        simd::float4 normal;
        simd::float4 uv;
        simd::float4 color;
    };
    
    struct BSBoneAnimVertex {
        simd::float4 position;  // derived from BSVertex
        simd::float4 normal;    // derived from BSVertex
        simd::float4 uv;        // derived from BSVertex
        simd::float4 color;     // derived from BSVertex
        simd::ushort4 boneIdx;
        simd::float4  weights;  // 4 weights
    };
    
}

#endif
