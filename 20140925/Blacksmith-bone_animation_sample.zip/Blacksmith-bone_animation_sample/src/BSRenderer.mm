//
//  BSRenderer.mm
//  MetalChallenge001
//
//  Created by takaura-f on 2014/07/16.
//  Copyright (c) 2014 KLab Inc. All rights reserved.
//

#import "BSRenderer.h"
#import <simd/simd.h>

#include <map>

#include "BSModel.hpp"
#import "BSMTLHelper.h"
#include "BSMath.hpp"
using namespace BS;


static const long inFlightCommandBuffers = 3;
static BOOL UseStencil = NO;

@implementation BSRenderer
{
@private
    id<MTLDevice> device;
    id<MTLCommandQueue> commandQueue;
    id<MTLLibrary> library;
    
    dispatch_semaphore_t inflight_semaphore;
    
}

static std::shared_ptr<BS::BSAnimModel> model;

-(instancetype)initWithDevice:(id<MTLDevice>)aDevice {
    self = [super init];
    if(self) {
        device = aDevice;
        SetCurrentDevice( aDevice );  // TODO: This implimentation assumes that MTLDevice is singleton object.
        
        commandQueue = [device newCommandQueue];
        library = [device newDefaultLibrary];
        if(!library) {
            NSLog(@">> ERROR: Couldnt create a default shader library");
            assert(0);
        }
        inflight_semaphore = dispatch_semaphore_create(inFlightCommandBuffers);
        
        model = BS::BSAnimModel::Create([[[NSBundle mainBundle] pathForResource:@"sample_bone_anim" ofType:@"dae"] UTF8String],inFlightCommandBuffers);
    }
    return self;
}

static CGSize viewSize;
-(void)reshape:(CGSize)size {
    viewSize = size;
}

static simd::float4x4 rotMat = MakeUnitMatrix();
-(void)render:(id<CAMetalDrawable>)drawable pixelFormat:(MTLPixelFormat)pixelFormat {
    
    dispatch_semaphore_wait(inflight_semaphore, DISPATCH_TIME_FOREVER);
    
    static unsigned int frameIndex = 0;
    
    id<MTLCommandBuffer> commandBuffer = [commandQueue commandBuffer];
    
    id<MTLTexture> texture = drawable.texture;
    MTLRenderPassDescriptor* renderPassDescriptor = [MTLRenderPassDescriptor renderPassDescriptor];
    
    { // color
        MTLRenderPassColorAttachmentDescriptor* colorAttachment = renderPassDescriptor.colorAttachments[0];
        colorAttachment.texture = texture;
        //colorAttachment.resolveTexture = texture;
        colorAttachment.loadAction = MTLLoadActionClear;
        colorAttachment.clearColor = MTLClearColorMake(0.0, 1.0, 0.0, 1.0);
        colorAttachment.storeAction = MTLStoreActionStore;// store only attachments that will be presented to the screen
    }

    { // depth
        static id<MTLTexture> depthTex = nil;
        if( depthTex && ( texture.width != depthTex.width || texture.height != depthTex.height ) ) {
            depthTex = nil;
        }
        if( depthTex == nil ) {
            MTLTextureDescriptor* texDesc = [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatDepth32Float
                                                                                               width:texture.width
                                                                                              height:texture.height
                                                                                           mipmapped:NO];
            texDesc.textureType = MTLTextureType2D;
            texDesc.sampleCount = 1;
            depthTex = [device newTextureWithDescriptor:texDesc];
        }
        MTLRenderPassDepthAttachmentDescriptor* depthAttachment = renderPassDescriptor.depthAttachment;
        depthAttachment.texture = depthTex;
        depthAttachment.loadAction = MTLLoadActionClear;
        depthAttachment.storeAction = MTLStoreActionDontCare;
        depthAttachment.clearDepth = 1.0;
    }
    
    if( UseStencil ){ // stencil
    // TODO: stencil texture
    //            MTLRenderPassStencilAttachmentDescriptor* stencilAttachment = renderPassDescriptor.stencilAttachment;
    //            MTLTextureDescriptor* texDesc = [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatStencil8
    //                                                                                               width:texture.width
    //                                                                                              height:texture.height
    //                                                                                           mipmapped:NO];
    //            texDesc.textureType = MTLTextureType2D;
    //            texDesc.sampleCount = 1;
    //            stencilAttachment.texture = [device newTextureWithDescriptor:texDesc];
    //            stencilAttachment.loadAction = MTLLoadActionClear;
    //            stencilAttachment.storeAction = MTLStoreActionDontCare;
    //            stencilAttachment.clearStencil = 0;
    }
    
    { // Render model
        static float anim_time = 0.0f;
        model->calcBone("combinedAnim_1", anim_time);
        anim_time += 0.02f;
        if(anim_time>1.0) {anim_time=0.0f;}
        
        static id<MTLRenderPipelineState> renderPipelineState = nil;
        if( renderPipelineState == nil ) {
            MTLRenderPipelineDescriptor* renderPipelineDescriptor = [MTLRenderPipelineDescriptor new];
            renderPipelineDescriptor.colorAttachments[0].pixelFormat = pixelFormat; // MTLPixelFormatBGRA8Unorm
            renderPipelineDescriptor.depthAttachmentPixelFormat = MTLPixelFormatDepth32Float;
            [renderPipelineDescriptor setSampleCount:1];
            id<MTLFunction> vertexProgram = [library newFunctionWithName:@"vertexShaderWithBoneAnimation"];
            if( !vertexProgram ) { NSLog(@">> ERROR: Couldnt load vertex function from default library"); }
            [renderPipelineDescriptor setVertexFunction:vertexProgram];
            id<MTLFunction> fragmentProgram = [library newFunctionWithName:@"fragmentShader"];
            if( !fragmentProgram ) { NSLog(@">> ERROR: Couldnt load fragment function from default library"); }
            [renderPipelineDescriptor setFragmentFunction:fragmentProgram];
            renderPipelineState = [device newRenderPipelineStateWithDescriptor:renderPipelineDescriptor error:nil];
        }
        
        id<MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
        
        std::map<std::string,BS::BSRenderingDataWithAnimation> renderingData = model->getRenderingDataWithAnimation();
        for( std::pair<std::string,BS::BSRenderingDataWithAnimation> currentData : renderingData ) {

            [renderEncoder pushDebugGroup:[NSString stringWithFormat:@"model(material %s)",currentData.first.c_str()]];
            [renderEncoder setRenderPipelineState:renderPipelineState];
            
            static id <MTLDepthStencilState> depthState = nil;
            if( depthState == nil ) {  // depth stencil state
                MTLDepthStencilDescriptor *depthStateDesc = [[MTLDepthStencilDescriptor alloc] init];
                depthStateDesc.depthCompareFunction = MTLCompareFunctionLess;
                depthStateDesc.depthWriteEnabled = YES;
                depthState = [device newDepthStencilStateWithDescriptor:depthStateDesc];
            }
            [renderEncoder setDepthStencilState:depthState];
            
            {  // vertex
                // vertex buffer
                [renderEncoder setVertexBuffer:BSMTLBufferToMTLBuffer(currentData.second.vertexBuffer) offset:0 atIndex:2];
                // bone matrix buffer
                [renderEncoder setVertexBuffer:BSMTLBufferToMTLBuffer(currentData.second.boneMatrixBuffer) offset:0 atIndex:3];
                
                const simd::float4x4 projMat = BS::perspectiveFov(60.0f, (float)viewSize.width/(float)viewSize.height, 0.1f, 10000.0f);
                const simd::float3 eye = simd::float3{0.0f,0.0f,0.0f};
                const simd::float3 center = simd::float3{0.0f,0.0f,1.0f};
                const simd::float3 up = simd::float3{0.0f,1.0f,0.0f};
                const simd::float4x4 viewMat = BS::lookAt(eye,center,up);
                
                // model matrix
                const float scale = 5.0f;//0.04f;
                const simd::float4x4 scaleMat = BS::scale( {scale,scale,scale,1.0f} );
                const simd::float4x4 posMat = BS::translate( { 0.0f,-2.0f,6.0f, 1.0f} );
                
                // projectionMatrix * viewMatrix * modelMatrix
                static id<MTLBuffer> pvm[inFlightCommandBuffers] = {nil};
                if( pvm[frameIndex] == nil ) {
                    pvm[frameIndex] = [device newBufferWithLength:sizeof(simd::float4x4) options:0];
                }
                simd::float4x4 *pvmMat = (simd::float4x4*)[pvm[frameIndex] contents];
                *pvmMat = projMat * viewMat * (posMat * rotMat * scaleMat);
                [renderEncoder setVertexBuffer:pvm[frameIndex] offset:0 atIndex:0];
                
                // normal matrix
                static id<MTLBuffer> normalMatrix[inFlightCommandBuffers] = {nil};
                if( normalMatrix[frameIndex] == nil ) {
                    normalMatrix[frameIndex] = [device newBufferWithLength:sizeof(simd::float4x4) options:0];
                }
                simd::float4x4 *norMat = (simd::float4x4*)[normalMatrix[frameIndex] contents];
                *norMat = simd::inverse(simd::transpose( BS::lookAt(eye,{center.x,center.y,-center.z},up) * rotMat ));
                [renderEncoder setVertexBuffer:normalMatrix[frameIndex] offset:0 atIndex:1];
            }
            
            {  // fragment
                id<MTLTexture> diffuseTexture = BSMTLTextureToMTLTexture(currentData.second.textureSet->diffuse[0]);
                if( diffuseTexture ) {
                    [renderEncoder setFragmentTexture:diffuseTexture atIndex:0];
                    
                    // create a sampler for the quad
                    static id <MTLSamplerState> sampler = nil;
                    if( sampler == nil ) {
                        MTLSamplerDescriptor* pSamplerDescriptor = [MTLSamplerDescriptor new];
                        pSamplerDescriptor.minFilter             = MTLSamplerMinMagFilterNearest;
                        pSamplerDescriptor.magFilter             = MTLSamplerMinMagFilterNearest;
                        pSamplerDescriptor.mipFilter             = MTLSamplerMipFilterNotMipmapped;
                        pSamplerDescriptor.maxAnisotropy         = 1.0f;
                        pSamplerDescriptor.sAddressMode          = MTLSamplerAddressModeClampToEdge;
                        pSamplerDescriptor.tAddressMode          = MTLSamplerAddressModeClampToEdge;
                        pSamplerDescriptor.rAddressMode          = MTLSamplerAddressModeClampToEdge;
                        pSamplerDescriptor.normalizedCoordinates = YES;
                        pSamplerDescriptor.lodMinClamp           = 0;
                        pSamplerDescriptor.lodMaxClamp           = FLT_MAX;
                        
                        sampler = [device newSamplerStateWithDescriptor:pSamplerDescriptor];
                        pSamplerDescriptor = nil;
                    }
                    [renderEncoder setFragmentSamplerState:sampler atIndex:0];
                }
            }

            [renderEncoder drawIndexedPrimitives:MTLPrimitiveTypeTriangle indexCount:currentData.second.vertexIndexCount indexType:MTLIndexTypeUInt32 indexBuffer:BSMTLBufferToMTLBuffer(currentData.second.vertexIndexBuffer) indexBufferOffset:0 instanceCount:1];
            [renderEncoder popDebugGroup];
        }
        [renderEncoder endEncoding];
    }
    
    __block dispatch_semaphore_t block_semaphore = inflight_semaphore;
    [commandBuffer addCompletedHandler:^(id<MTLCommandBuffer>){
        dispatch_semaphore_signal(block_semaphore);
    }];
    
    frameIndex = (++frameIndex) % inFlightCommandBuffers;
    
    [commandBuffer presentDrawable:drawable];
    [commandBuffer commit];
}

static CGPoint prePos = CGPointMake(0.0f,0.0f);
-(void)touchesBeganFromView:(UIView*)view touches:(NSSet *)touches {
    const CGPoint pos = [[touches anyObject] locationInView:view];
    
    prePos = pos;
}
-(void)touchesMovedFromView:(UIView*)view touches:(NSSet *)touches {
    const CGPoint pos = [[touches anyObject] locationInView:view];
    
    const CGPoint dist = CGPointMake(pos.x-prePos.x,-(pos.y-prePos.y));
    const float rot = sqrtf( dist.x*dist.x + dist.y*dist.y );
    const simd::float3 axis = { (float)dist.y, -(float)dist.x, 0.0f };
    
    rotMat = BS::rotate(rot, axis) * rotMat;
    
    prePos = pos;
}
-(void)touchesEndedFromView:(UIView*)view touches:(NSSet *)touches {
    const CGPoint pos = [[touches anyObject] locationInView:view];
    
    prePos = pos;
}

@end
