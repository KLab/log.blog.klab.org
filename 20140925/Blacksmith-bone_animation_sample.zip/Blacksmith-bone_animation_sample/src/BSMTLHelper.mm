//
//  BSMTLHelper.m
//  Blacksmith_iOS
//
//  Created by takaura-f on 2014/08/08.
//  Copyright (c) 2014 KLab Inc. All rights reserved.
//

#import <Metal/Metal.h>

static id<MTLDevice> currentDevice = nil;
id<MTLDevice> GetCurrentDevice() {
    if( currentDevice == nil ) {
        NSLog(@"Error: current device is nil.");
    }
    return currentDevice;
}
void SetCurrentDevice( id<MTLDevice> device ) {
    currentDevice = device;
}


