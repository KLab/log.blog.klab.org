#include <stdio.h>
#include <pthread.h>
#include <string.h>

void foobar()
{
}

void foo()
{
}

void bar()
{
	foobar();
	foobar();
}

void tf1()
{
}

void tf2()
{
}

void *workthread(void* param)
{
	tf1();
	tf2();
	pthread_exit(param);	
}

int main(int argc, char *argv[])
{
	void *tresult;
	pthread_t thread=0;
	if(argc==2){
		if(!strcmp(argv[1],"-f")){
			if(!fork()){
				foobar();
			}
		}
		if(!strcmp(argv[1],"-t")){
			if(pthread_create(&thread, NULL, workthread, NULL)){
				printf("pthread_create error!\n");
			}else{
				pthread_join(thread, &tresult);
			}
		}
	}
	foo();
	bar();
	foo();
	return(0);
}

