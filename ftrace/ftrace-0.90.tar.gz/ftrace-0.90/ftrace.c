#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <bfd.h>
#include <limits.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <syslog.h>
#include <dlfcn.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>

#ifdef FTRACE_SHARE
static bfd *pbfd = NULL;
static asymbol **symbols = NULL;
static int nsymbol = 0;

void __cyg_profile_func_enter(void *func_address, void *call_site )
	__attribute__ ((no_instrument_function));

void __cyg_profile_func_exit(void *func_address, void *call_site)
	__attribute__ ((no_instrument_function));

void put_info(char *info)
{
	int fd = 2;
	struct timeval  tv;
	struct timezone tz;
	struct tm t;
	char buff[1024];
	char fname[PATH_MAX];
	const char *dfpath = "ftrace";
	const char *target = getenv("FTRACE_OUTPUT");
	const char *ftpath = getenv("FTRACE_PATH");
	const char *stflag = getenv("FTRACE_SPLIT_THREAD_S");
	const char *dtflag = getenv("FTRACE_SPLIT_THREAD_L");

	if(target){
		if(!strcmp(target,"syslog")){
			if(dtflag){
				syslog(LOG_INFO, "[%05d.%u] %s", getpid(), pthread_self(), info);
			}else{
				syslog(LOG_INFO, "[%05d] %s", getpid(), info);
			}
			return;
		}else{
			if(!strcmp(target,"file")){
				if(!ftpath){
					ftpath = dfpath;
				}
				if(stflag){
					sprintf(fname,"%s.%d.%u", ftpath, getpid(), pthread_self());
				}else{
					sprintf(fname,"%s.%d", ftpath, getpid());
				}
				fd=open(fname, O_WRONLY|O_CREAT|O_APPEND, S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH);
				if(fd == -1){
					fd = 2;
				}
			}      
		}
	}
	gettimeofday(&tv,&tz);
	localtime_r(&(tv.tv_sec), &t);

	if(dtflag){
		sprintf(buff, "%02d:%02d:%02d.%06d [%05d.%u] %s\n", t.tm_hour, t.tm_min, t.tm_sec, tv.tv_usec, getpid(), pthread_self(), info);
	}else{
		sprintf(buff, "%02d:%02d:%02d.%06d [%05d] %s\n", t.tm_hour, t.tm_min, t.tm_sec, tv.tv_usec, getpid(), info);
	}
	write(fd, buff, strlen(buff)); 
	if(fd != 2){
		close(fd);
	}
}

void get_info(void *address, char *info, int mode)
{
	int indent;
	int lineno;
	int found;
	asection   *section;
	const char *file_name;
	const char *function_name;
	const char *io_info[] = {"enter","exit"};
	char format[256];
	char envname[64];
	char envval[64];
	char srcpath[PATH_MAX];
	char srcbase[PATH_MAX];
	char *envptr;

	section = bfd_get_section_by_name(pbfd, ".debug_info");
	found = bfd_find_nearest_line(pbfd, section, symbols, (long)address, &file_name, &function_name, &lineno);
	if(found && file_name != NULL && function_name != NULL) {
		sprintf(envname, "FTRACE_INDENT_%05u_%u", getpid(), pthread_self());
		if(envptr=getenv(envname)){
			indent = atoi(envptr);
		}else{
			indent = 0;
		}
		indent -= (mode && indent);
		strcpy(srcpath, file_name);
		strcpy(srcbase, (const char*)basename(srcpath));
		srcbase[16]=0;
		sprintf(format, "%%-16s:%%%ds%%s(%%s)", indent * 2 + 1);
		sprintf(info, format, srcbase, "", function_name, io_info[mode]);
		indent += (!mode);
		sprintf(envval, "%d", indent);
		setenv(envname, envval, 1);
	}
}

void
__attribute__((constructor))
init_symbols()
{
	int size;
	pbfd = bfd_openr("/proc/self/exe", NULL);
	bfd_check_format(pbfd, bfd_object);
	size = bfd_get_symtab_upper_bound(pbfd);
	symbols = (asymbol **)malloc(size);
	nsymbol = bfd_canonicalize_symtab(pbfd, symbols);
}

void __cyg_profile_func_enter(void *this, void *callsite)
{
	char info[1024];
	get_info(this, info, 0);
	put_info(info);
}

void __cyg_profile_func_exit(void *this, void *callsite)
{
	char info[1024];
	get_info(this, info, 1);
	put_info(info);
}

pid_t fork()
{
	pid_t pid;
	pid_t (*fork_org)(void);
	char  info[256];
	fork_org = dlsym(RTLD_NEXT,"fork");
	pid = (*fork_org)();
	sprintf(info,"%-16s: pid=%05u","fork()",pid);
	put_info(info);
	return(pid);
}

int pthread_create(pthread_t *thread, pthread_attr_t * attr, void * (*start_routine)(void *), void * arg)
{
	int result;
	char info[256];
	int (*pthread_create_org)(pthread_t * thread, pthread_attr_t * attr, void * (*start_routine)(void *), void * arg);
	pthread_create_org = dlsym(RTLD_NEXT,"pthread_create");
	result=(*pthread_create_org)(thread, attr, start_routine, arg);
	if(thread){
		sprintf(info,"%-16s: result=%d TID=%u", "pthread_create()", result, *thread);
	}else{
		sprintf(info,"%-16s: result=%d       ", "pthread_create()", result, *thread);
	}
	put_info(info);

	return(result);
}

void pthread_exit(void *retval)
{
	char  info[256];
	void (*pthread_exit_org)(void *retval);
	pthread_exit_org = dlsym(RTLD_NEXT,"pthread_exit");
	sprintf(info,"%-16s: retval=%p", "pthread_exit()", retval);
	put_info(info);
	(*pthread_exit_org)(retval);
	/* not reach */
	exit(0);
}

#else
void usage()
{
	printf("Version %s\n", FTRACE_VER);
	printf("usage: ftrace [-s] [-o file] [-t] [-T] command [arg ...]\n");
	printf("option\n");
	printf("  -s   : output to syslog\n");
	printf("  -o   : output to file   (FileName: file.pid)\n");
	printf("  -t   : with '-o' option (FileName: file.pid.thread_id)\n");
	printf("  -T   : thread_id added to the output format of pid.\n\n");
}

int main(int argc,char *argv[])
{
	int i,j;
	char so[PATH_MAX];

	sprintf(so, "%s/libftrace.so", FTRACE_LIB);
	setenv("LD_PRELOAD", so, 1);

	if(argc == 1){
		usage();
		exit(0);
	} 
	for(i=1;i<argc;i++){
		if(argv[i][0] == '-'){
			switch(argv[i][1]){
				case 's':
					unsetenv("FTRACE_PATH");
					setenv("FTRACE_OUTPUT", "syslog", 1);
					break;
				case 'o':
					setenv("FTRACE_PATH",   argv[++i], 1);
					setenv("FTRACE_OUTPUT", "file",    1);
					break;
				case 't':
					setenv("FTRACE_SPLIT_THREAD_S","1",1);
					break;
				case 'T':
					setenv("FTRACE_SPLIT_THREAD_L","1",1);
					break;
				case 'h':
					usage();
					return(0);
			}
		}else{
			execvp(argv[i], argv + i);
			fprintf(stderr,"cant exec %s\n", argv[i]);
			exit(1);
		}
	}
	usage();
	return(1);
}
#endif

