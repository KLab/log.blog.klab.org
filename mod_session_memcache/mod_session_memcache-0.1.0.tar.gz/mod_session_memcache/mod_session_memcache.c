/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "mod_session.h"
#include "apr_lib.h"
#include "apr_strings.h"
#include "http_log.h"
#include "util_cookies.h"
#include "mpm_common.h"

#include <memcache.h>

#define LOG_PREFIX "mod_session_memcache: "
#define MOD_SESSION_MEMCACHE "mod_session_memcache"

module AP_MODULE_DECLARE_DATA session_memcache_module;

/*
 * this module is derived from mod_session_dbd, so each function resembles
 * in their names and logics.
 *
 */

/**
 * Structure to carry the per-dir session config.
 */
typedef struct {
    const char *name;
    int name_set;
    const char *name_attrs;
    const char *name2;
    int name2_set;
    const char *name2_attrs;
    int peruser;
    int peruser_set;
    int remove;
    int remove_set;
    const char *server;
} session_memcache_dir_conf;

static struct memcache*
_mc_create(session_memcache_dir_conf *conf, request_rec *r)
{
    struct memcache *mc = mc_new();
    const char *serv = "localhost:11211";
    int ret;

    if (conf && conf->server) {
        serv = conf->server;
    }

    ap_log_rerror(APLOG_MARK, APLOG_DEBUG, 0, r, LOG_PREFIX
                  "memcache server [%s]", serv);

    ret = mc_server_add4(mc, serv);
    if (ret != MCM_ERR_NONE) {
        mc_free(mc);
        return NULL;
    }

    return mc;
}

/**
 * Load the session by the key specified.
 */
static apr_status_t memcache_load(request_rec * r, const char *key, const char **val)
{
    int ret;
    struct memcache *mc;
    char *tmp = NULL;

    session_memcache_dir_conf *conf = ap_get_module_config(r->per_dir_config,
                                                           &session_memcache_module);

    mc = _mc_create(conf, r);
    if (!mc) {
        return APR_EGENERAL;
    }

    tmp = mc_aget(mc, (char*)key, strlen(key));
    *val = (const char*)apr_pstrdup(r->pool, tmp);
    free(tmp);

    mc_free(mc);
    return APR_SUCCESS;
}

/**
 * Load the session from memcache
 *
 * If the session is anonymous, the session key will be extracted from
 * the cookie specified. Failing that, the session key will be extracted
 * from the GET parameters.
 *
 * If the session is keyed by the username, the session will be extracted
 * by that.
 *
 * If no session is found, an empty session will be created.
 *
 * On success, this returns OK.
 */
static int session_memcache_load(request_rec * r, session_rec ** z)
{

    session_memcache_dir_conf *conf = ap_get_module_config(r->per_dir_config,
                                                           &session_memcache_module);

    apr_status_t ret = APR_SUCCESS;
    session_rec *zz = NULL;
    const char *name = NULL;
    const char *note = NULL;
    const char *val = NULL;
    const char *key = NULL;
    request_rec *m = r->main ? r->main : r;

    /* is our session in a cookie? */
    if (conf->name2_set) {
        name = conf->name2;
    }
    else if (conf->name_set) {
        name = conf->name;
    }
    else if (conf->peruser_set && r->user) {
        name = r->user;
    }
    else {
        return DECLINED;
    }

    /* first look in the notes */
    note = apr_pstrcat(r->pool, MOD_SESSION_MEMCACHE, name, NULL);
    zz = (session_rec *)apr_table_get(m->notes, note);
    if (zz) {
        *z = zz;
        return OK;
    }

    /* load anonymous sessions */
    if (conf->name_set || conf->name2_set) {

        /* load an RFC2109 or RFC2965 compliant cookie */
        ap_cookie_read(r, name, &key, conf->remove);
        if (key) {
            ret = memcache_load(r, key, &val);
            if (ret != APR_SUCCESS) {
                return ret;
            }
        }

    }

    /* load named session */
    else if (conf->peruser) {
        if (r->user) {
            ret = memcache_load(r, r->user, &val);
            if (ret != APR_SUCCESS) {
                return ret;
            }
        }
    }

    /* otherwise not for us */
    else {
        return DECLINED;
    }

    /* create a new session and return it */
    zz = (session_rec *) apr_pcalloc(r->pool, sizeof(session_rec));
    zz->pool = r->pool;
    zz->entries = apr_table_make(zz->pool, 10);
    zz->uuid = (apr_uuid_t *) apr_pcalloc(zz->pool, sizeof(apr_uuid_t));
    if (key) {
        apr_uuid_parse(zz->uuid, key);
    }
    else {
        apr_uuid_get(zz->uuid);
    }
    zz->encoded = val;
    *z = zz;

    /* put the session in the notes so we don't have to parse it again */
    apr_table_setn(m->notes, note, (char *)zz);

    return OK;

}

/**
 * Save the session by the key specified.
 */
static apr_status_t memcache_save(request_rec * r, const char *key, const char *val, apr_int64_t expiry)
{
    int ret;

    int rows = 0;
    struct memcache* mc;
    time_t expt = apr_time_sec(expiry);

    session_memcache_dir_conf *conf = ap_get_module_config(r->per_dir_config,
                                                           &session_memcache_module);

    mc = _mc_create(conf, r);
    if (!mc) {
        return APR_EGENERAL;
    }

    ret = mc_set(mc, (char*)key, strlen(key), val, strlen(val), expt, 0);
    mc_free(mc);

    if (ret != MCM_ERR_NONE) {
        ap_log_rerror(APLOG_MARK, APLOG_ERR, 0, r, LOG_PREFIX
                      "memcache storing error occurred. [key=(%s),expiry=(%d)]", key, expt);
        return APR_EGENERAL;
    }

    return APR_SUCCESS;

}

/**
 * Remove the session by the key specified.
 */
static apr_status_t memcache_remove(request_rec * r, const char *key)
{
    int ret;
    struct memcache* mc = NULL;

    session_memcache_dir_conf *conf = ap_get_module_config(r->per_dir_config,
                                                           &session_memcache_module);

    mc = mc_new();

    mc = _mc_create(conf, r);
    if (!mc) {
        return APR_EGENERAL;
    }

    ret = mc_delete(mc, (char*)key, strlen(key), 0);
    mc_free(mc);

    if (ret != MCM_ERR_NONE) {
        ap_log_rerror(APLOG_MARK, APLOG_ERR, APR_EGENERAL, r, LOG_PREFIX
                      "query execution error removing session '%s' "
                      "from memcache", key);
        return APR_EGENERAL;
    }

    return APR_SUCCESS;

}

/**
 * Clean out expired sessions.
 *
 * not implemented yet.
 */
static apr_status_t memcache_clean(apr_pool_t *p, server_rec *s)
{

    return APR_ENOTIMPL;

}

/**
 * Save the session onto memcache.
 *
 * If the session is anonymous, save the session and write a cookie
 * containing the uuid.
 *
 * If the session is keyed to the username, save the session using
 * the username as a key.
 *
 * On success, this method will return APR_SUCCESS.
 *
 * @param r The request pointer.
 * @param z A pointer to where the session will be written.
 */
static int session_memcache_save(request_rec * r, session_rec * z)
{

    char *buffer;
    apr_status_t ret = APR_SUCCESS;
    session_memcache_dir_conf *conf = ap_get_module_config(r->per_dir_config,
                                                           &session_memcache_module);

    /* support anonymous sessions */
    if (conf->name_set || conf->name2_set) {

        /* don't cache pages with a session */
        apr_table_addn(r->headers_out, "Cache-Control", "no-cache");

        /* must we create a uuid? */
        buffer = apr_pcalloc(r->pool, APR_UUID_FORMATTED_LENGTH + 1);
        apr_uuid_format(buffer, z->uuid);

        /* save the session with the uuid as key */
        if (z->encoded && z->encoded[0]) {
            ret = memcache_save(r, buffer, z->encoded, z->expiry);
        }
        else {
            ret = memcache_remove(r, buffer);
        }
        if (ret != APR_SUCCESS) {
            return ret;
        }

        /* create RFC2109 compliant cookie */
        if (conf->name_set) {
            ap_cookie_write(r, conf->name, buffer, conf->name_attrs, z->maxage, r->headers_out, r->err_headers_out, NULL);
        }

        /* create RFC2965 compliant cookie */
        if (conf->name2_set) {
            ap_cookie_write2(r, conf->name2, buffer, conf->name2_attrs, z->maxage, r->headers_out, r->err_headers_out, NULL);
        }

        return OK;

    }

    /* save named session */
    else if (conf->peruser) {

        /* don't cache pages with a session */
        apr_table_addn(r->headers_out, "Cache-Control", "no-cache");

        if (r->user) {
            ret = memcache_save(r, r->user, z->encoded, z->expiry);
            if (ret != APR_SUCCESS) {
                return ret;
            }
            return OK;
        }
        else {
            ap_log_rerror(APLOG_MARK, APLOG_ERR, 0, r, LOG_PREFIX
               "peruser sessions can only be saved if a user is logged in, "
                          "session not saved: %s", r->uri);
        }
    }

    return DECLINED;

}

/**
 * This function performs housekeeping on the memcached, deleting expired
 * sessions.
 */
static int session_memcache_monitor(apr_pool_t *p, server_rec *s)
{
    /* TODO handle housekeeping */
    memcache_clean(p, s);
    return OK;
}


static void *create_session_memcache_dir_config(apr_pool_t * p, char *dummy)
{
    session_memcache_dir_conf *new =
    (session_memcache_dir_conf *) apr_pcalloc(p, sizeof(session_memcache_dir_conf));

    new->remove = 1;

    return (void *) new;
}

static void *merge_session_memcache_dir_config(apr_pool_t * p, void *basev, void *addv)
{
    session_memcache_dir_conf *new = (session_memcache_dir_conf *) apr_pcalloc(p, sizeof(session_memcache_dir_conf));
    session_memcache_dir_conf *add = (session_memcache_dir_conf *) addv;
    session_memcache_dir_conf *base = (session_memcache_dir_conf *) basev;

    new->name = (add->name_set == 0) ? base->name : add->name;
    new->name_attrs = (add->name_set == 0) ? base->name_attrs : add->name_attrs;
    new->name_set = add->name_set || base->name_set;
    new->name2 = (add->name2_set == 0) ? base->name2 : add->name2;
    new->name2_attrs = (add->name2_set == 0) ? base->name2_attrs : add->name2_attrs;
    new->name2_set = add->name2_set || base->name2_set;
    new->peruser = (add->peruser_set == 0) ? base->peruser : add->peruser;
    new->peruser_set = add->peruser_set || base->peruser_set;
    new->remove = (add->remove_set == 0) ? base->remove : add->remove;
    new->remove_set = add->remove_set || base->remove_set;

    return new;
}

/**
 * Sanity check a given string that it exists, is not empty,
 * and does not contain special characters.
 */
static const char *check_string(cmd_parms * cmd, const char *string)
{
    if (APR_SUCCESS != ap_cookie_check_string(string)) {
        return apr_pstrcat(cmd->pool, cmd->directive->directive,
                           " cannot be empty, or contain '=', ';' or '&'.",
                           NULL);
    }
    return NULL;
}

static const char *
     set_memcache_peruser(cmd_parms * parms, void *dconf, int flag)
{
    session_memcache_dir_conf *conf = dconf;

    conf->peruser = flag;
    conf->peruser_set = 1;

    return NULL;
}

static const char *
     set_memcache_cookie_remove(cmd_parms * parms, void *dconf, int flag)
{
    session_memcache_dir_conf *conf = dconf;

    conf->remove = flag;
    conf->remove_set = 1;

    return NULL;
}

static const char *set_cookie_name(cmd_parms * cmd, void *config, const char *args)
{
    char *last;
    char *line = apr_pstrdup(cmd->pool, args);
    session_memcache_dir_conf *conf = (session_memcache_dir_conf *) config;
    char *cookie = apr_strtok(line, " \t", &last);
    conf->name = cookie;
    conf->name_set = 1;
    while (apr_isspace(*last)) {
        last++;
    }
    conf->name_attrs = last;
    return check_string(cmd, cookie);
}

static const char *set_cookie_name2(cmd_parms * cmd, void *config, const char *args)
{
    char *last;
    char *line = apr_pstrdup(cmd->pool, args);
    session_memcache_dir_conf *conf = (session_memcache_dir_conf *) config;
    char *cookie = apr_strtok(line, " \t", &last);
    conf->name2 = cookie;
    conf->name2_set = 1;
    while (apr_isspace(*last)) {
        last++;
    }
    conf->name2_attrs = last;
    return check_string(cmd, cookie);
}

static const char *set_memcache_server(cmd_parms *cmd, void *config, const char* args)
{
    session_memcache_dir_conf *conf = (session_memcache_dir_conf *) config;
    conf->server = args;
    return NULL;
}

static const command_rec session_memcache_cmds[] =
{
    AP_INIT_FLAG("SessionMemcachePerUser", set_memcache_peruser, NULL, RSRC_CONF|OR_AUTHCFG,
                 "Save the session per user"),
    AP_INIT_FLAG("SessionMemcacheCookieRemove", set_memcache_cookie_remove, NULL, RSRC_CONF|OR_AUTHCFG,
                 "Remove the session cookie after session load. On by default."),
    AP_INIT_RAW_ARGS("SessionMemcacheCookieName", set_cookie_name, NULL, RSRC_CONF|OR_AUTHCFG,
                 "The name of the RFC2109 cookie carrying the session key"),
    AP_INIT_RAW_ARGS("SessionMemcacheCookieName2", set_cookie_name2, NULL, RSRC_CONF|OR_AUTHCFG,
                 "The name of the RFC2965 cookie carrying the session key"),
    AP_INIT_TAKE1("SessionMemcacheServer", set_memcache_server, NULL, RSRC_CONF|OR_AUTHCFG,
                  "The server address and port for session storage"),
    {NULL}
};

static void register_hooks(apr_pool_t * p)
{
    ap_hook_session_load(session_memcache_load, NULL, NULL, APR_HOOK_MIDDLE);
    ap_hook_session_save(session_memcache_save, NULL, NULL, APR_HOOK_MIDDLE);
    ap_hook_monitor(session_memcache_monitor, NULL, NULL, APR_HOOK_MIDDLE);
}

module AP_MODULE_DECLARE_DATA session_memcache_module =
{
    STANDARD20_MODULE_STUFF,
    create_session_memcache_dir_config, /* dir config creater */
    merge_session_memcache_dir_config,  /* dir merger --- default is to
                                    * override */
    NULL,                          /* server config */
    NULL,                          /* merge server config */
    session_memcache_cmds,              /* command apr_table_t */
    register_hooks                 /* register hooks */
};
